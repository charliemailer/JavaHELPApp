package com.example.helpr

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

                                //INHERITED CODE FROM THIS TUTORIAL
                                //https://www.youtube.com/watch?v=TN97RRR-7bk

class FindMe : AppCompatActivity(), OnMapReadyCallback {

    //declare variables which will be used to call functions
    private lateinit var map: GoogleMap
    private val LOCATION_PERMISSION_REQUEST = 1

    //Checks if the device access is given by the user or not - if true then the button to pinpoint your location is shown
    private fun getLocationAccess() {
        if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED) {
            map.isMyLocationEnabled = true
        }
        else //if not true, request the user to enable access to location
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST)
    }
    //if the user allows access, the request code and grant results both become equal to 1 and enables the location layer of the map to run
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if (grantResults.contains(PackageManager.PERMISSION_GRANTED)) {
                if (ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return
                }
                map.isMyLocationEnabled = true
            }
            else { //if the user denies permission, a toast notifcation appears confirming that the user has not granted location access permission
                Toast.makeText(this, "User has not granted location access permission", Toast.LENGTH_LONG).show()
                finish() //terminates the app
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }


    //manipulates the map once available
    //callback is triggered when the map is ready to be used
    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap //googleMap assigned to map variable
        getLocationAccess() //calling location access on google map view

        // Add a marker in Sydney and move the camera
        val scotland = LatLng(55.9533, 3.1883) //setting the latitude and longitude to scotland co-ordinates
        val zoomLevel = 5f //set zoom level to show closer screen view                                                                  //change marker colour to blue
        map.addMarker(MarkerOptions().position(scotland).title("Marker in Scotland").icon(
            BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN)))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(scotland, zoomLevel)) //ability to move camera while staying zoomed in
    }
}