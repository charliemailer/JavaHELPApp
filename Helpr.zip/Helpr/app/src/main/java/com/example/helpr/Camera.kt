package com.example.helpr

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_camera.*

class Camera : AppCompatActivity() {

                        //INHERITED CODE FROM THIS TUTORIAL
                        //https://devofandroid.blogspot.com/2018/09/take-picture-with-camera-android-studio_22.html

    //DECLARE VARIABLES AND VALUES
    private val PERMISSION_CODE = 1000
    private val IMAGE_CAPTURE_CODE = 1001
    var image_uri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //WHEN BUTTON IS CLICKED...
        btnCapture.setOnClickListener {
            //IF THE SYSTEM OPERATING SYSTEM IS MARSHMALLOW OR ABOVE...
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

                //REQUEST RUNTIME PERMISSION
                if (checkSelfPermission(Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_DENIED ||
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_DENIED){

                    //IF PERMISSION IS DENIED TO WRITE TO EXTERNAL STORAGE...
                    val permission = arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)

                    //A POP UP WILL APPEAR TO ASK FOR PERMISSION FROM THE USER
                    requestPermissions(permission, PERMISSION_CODE)
                }
                else{
                    //IF THE PERMISSION IS ALREADY GRANTED, THE CAMERA WILL OPEN HERE...
                    openCamera()
                }
            }
            else{
                //IF THE SYSTEM OS IS BELOW MARSHMALLOW, THE CAMERA WILL OPEN...
                openCamera()
            }
        }
    }

    private fun openCamera() {
        //DECLARE VALUES
        val values = ContentValues()

        //SAVE VALUES TITLE AND DESCRIPTION TO THE IMAGE URI
        values.put(MediaStore.Images.Media.TITLE, "New photo")
        values.put(MediaStore.Images.Media.DESCRIPTION, "Photo of an accident taken from the Camera")
        image_uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)

        //CAMERA INTENT
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri)
        startActivityForResult(cameraIntent, IMAGE_CAPTURE_CODE)
    }


    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {

        //REQUEST CODE CALLED WHEN THE USER PRESSES ALLOW OR DENY FROM THE PERMISSION POP UP
        when(requestCode){
            PERMISSION_CODE -> {
                if (grantResults.size > 0 && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED){
                    //PERMISSION WAS GRANTED SO OPEN CAMERA
                    openCamera()
                }
                else{
                    //SHOW TOAST MESSAGE WHEN THE PERMISSION HAS BEEN DENIED BY THE USER
                    Toast.makeText(this, "Permission has been denied.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        //IMAGE WAS CAPTURED FROM CAMERA INTENT
        if (resultCode == Activity.RESULT_OK){
            //SET IMAGE CAPTURED TO SHOW IN IMAGE VIEW
            imgView.setImageURI(image_uri)
        }
    }

}
