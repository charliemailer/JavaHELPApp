package com.example.helpr

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

                            //INHERITED CODE FROM THIS TUTORIAL
                            //https://www.tutorialspoint.com/how-to-make-a-phone-call-using-intent-in-android-using-kotlin

class EmergencyCall : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    //CREATES INTENT WHICH TAKES THE USER TO THE DIAL PAD AND HAS 999 ALREADY ENTERED.
    fun call(view: View) {
        val dialIntent = Intent(Intent.ACTION_DIAL)
        dialIntent.data = Uri.parse("tel:" + "999")
        startActivity(dialIntent)
    }
}