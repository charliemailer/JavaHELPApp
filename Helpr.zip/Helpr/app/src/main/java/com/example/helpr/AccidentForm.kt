package com.example.helpr

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.io.*
import java.lang.StringBuilder


                        //INHERITED CODE FROM THIS TUTORIAL AND USED IT TO CREATE THIS FORM
                        //https://www.javatpoint.com/kotlin-android-read-and-write-external-storage
                        //I ALSO INHERITED SOME CODE FROM THIS TUTORIAL
                        //https://www.javatpoint.com/kotlin-android-read-and-write-internal-storage


class AccidentForm : AppCompatActivity() {
    //DECLARE FOLDER THAT FORMS ARE SAVED TO
    private val filepath = "CarAccidentForms"
    internal var myExternalFile: File?=null

    //CHECK IF STORAGE TO READ ONLY
    private val isExternalStorageReadOnly: Boolean get() {
        val extStorageState = Environment.getExternalStorageState()
        return Environment.MEDIA_MOUNTED_READ_ONLY == extStorageState
    }

    //CHECK IF THERE IS AVAILABLE STORAGE
    private val isExternalStorageAvailable: Boolean get() {
        val extStorageState = Environment.getExternalStorageState()
        return Environment.MEDIA_MOUNTED == extStorageState
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        //DECLARE VALUES
        val fileDate = findViewById(R.id.txtDate) as? EditText
        val fileLocation = findViewById(R.id.txtLocation) as? EditText
        val fileDetails = findViewById(R.id.txtDetails) as? EditText
        val saveButton = findViewById<Button>(R.id.btnSave) as? Button

        saveButton?.setOnClickListener(View.OnClickListener {
            //SAVE THE FORM TO EXTERNAL FILES BY FILE DATE
            if (fileDate != null) {
                myExternalFile = File(getExternalFilesDir(filepath), fileDate.text.toString())
            }
            try {

                //DECLARE VALUE FILEOUTPUTSTREAM
                val fileOutPutStream = FileOutputStream(myExternalFile)

                //WRITE DATA FROM THE LOCATION AND DETAILS FIELDS TO THE VALUE FILEOUTPUTSTREAM
                if (fileLocation != null) {
                    fileOutPutStream.write(fileLocation.text.toString().toByteArray())
                }
                if (fileDetails != null) {
                    fileOutPutStream.write(fileDetails.text.toString().toByteArray())
                }
                fileOutPutStream.close()

            } catch (e: IOException) {
                e.printStackTrace()
            }
            //INFORM USER THAT THE FORM WAS SAVED SUCCESSFULLY
            Toast.makeText(applicationContext,"Form Saved Successfully.", Toast.LENGTH_SHORT).show()

            //CLEAR THE TEXT FIELDS AFTER THE FORM SAVED
            fileDate?.text?.clear()
            fileLocation?.text?.clear()
            fileDetails?.text?.clear()
        })

        //WHEN VIEW BUTTON IS CLICKED LOCATE THE FILE DATE THE USER HAS ENTERED IN THE FILEPATH
        (findViewById(R.id.btnView) as? Button)?.setOnClickListener(View.OnClickListener {
            if (fileDate != null) {
                myExternalFile = File(getExternalFilesDir(filepath), fileDate.text.toString())
            }

            //DECLARE VALUE
            val filedate = fileDate?.text.toString()

            myExternalFile = File(getExternalFilesDir(filepath),filedate)


            //DECLARE VALUES
            if(filedate.toString()!=null && filedate.toString().trim()!=""){

                var fileInputStream = FileInputStream(myExternalFile)
                var inputStreamReader: InputStreamReader = InputStreamReader(fileInputStream)
                val bufferedReader: BufferedReader = BufferedReader(inputStreamReader)
                val stringBuilder: StringBuilder = StringBuilder()
                var text: String? = null
                while ({ text = bufferedReader.readLine(); text }() != null) {
                    stringBuilder.append(text)
                }

                fileInputStream.close()

                //DISPLAY SAVED DATA IN FORM
                fileDetails?.setText(stringBuilder.toString())?.toString()

            }
        })

        //IF EXTERNAL STORAGE IS AVAILABLE AND ITS READ ONLY, SAVE FILE
        if (!isExternalStorageAvailable || isExternalStorageReadOnly) {
            if (saveButton != null) {
                saveButton.isEnabled = false
            }
        }
    }
}
