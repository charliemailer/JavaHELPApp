package com.example.helpr

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

                            //INHERITED CODE FROM THIS TUTORIAL
                            //https://www.tutorialkart.com/kotlin-android/android-start-another-activity/


class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //WHEN CLICKED THE USER IS TAKEN TO THE MAP ACTIVITY TO FIND THEIR LOCATION
        btnFindMe.setOnClickListener {
            val intent = Intent(this, FindMe::class.java)
            startActivity(intent)
        }

        //WHEN CLICKED THE USER IS TAKEN TO THE BUTTON WHERE THEY CAN CALL EMERGENCY SERVICES
        btnCall.setOnClickListener {
           val intent = Intent(this, EmergencyCall::class.java)
            startActivity(intent)
        }

        //WHEN CLICKED THE USER CAN FILL OUT AN ACCIDENT FORM
        btnAccident.setOnClickListener {
            val intent = Intent(this, AccidentForm::class.java)
            startActivity(intent)
        }

        //WHEN CLICKED THE USER CAN TAKE PICTURE WHICH WILL SAVE TO GALLERY
        btnCamera.setOnClickListener {
            val intent = Intent(this, Camera::class.java)
            startActivity(intent)
        }

    }
}